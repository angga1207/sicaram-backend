<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('data_realisasi_contracts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('data_realisasi_id');
            $table->unsignedBigInteger('rincian_id');
            $table->unsignedBigInteger('instance_id');
            $table->unsignedBigInteger('ref_kode_rekening_1')->nullable();
            $table->unsignedBigInteger('ref_kode_rekening_2')->nullable();
            $table->unsignedBigInteger('ref_kode_rekening_3')->nullable();
            $table->unsignedBigInteger('ref_kode_rekening_4')->nullable();
            $table->unsignedBigInteger('ref_kode_rekening_5')->nullable();
            $table->unsignedBigInteger('ref_kode_rekening_6')->nullable();
            $table->string('type', 20)->default('detail')->comment('detail, title');
            $table->longText('uraian')->nullable();

            $table->string('jenis_kontrak')->nullable();
            $table->string('nomor_kontrak')->nullable();
            $table->string('nilai_kontrak')->nullable();
            $table->string('jenis_pengadaan')->nullable();
            $table->date('tanggal_kontrak')->nullable();
            $table->string('tahap_pembayaran')->nullable();
            $table->string('jangka_waktu_pelaksanaan')->nullable();

            $table->enum('status', ['draft', 'verified', 'reject', 'return', 'sent', 'waiting'])->default('draft');
            $table->enum('editable_for', ['all', 'admin', 'user'])->default('all');
            $table->unsignedBigInteger('created_by');
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->unsignedBigInteger('deleted_by')->nullable();

            $table->foreign('data_realisasi_id')->references('id')->on('data_realisasi');
            $table->foreign('rincian_id')->references('id')->on('data_realisasi_rincian');
            $table->foreign('ref_kode_rekening_1')->references('id')->on('ref_kode_rekening_1');
            $table->foreign('ref_kode_rekening_2')->references('id')->on('ref_kode_rekening_2');
            $table->foreign('ref_kode_rekening_3')->references('id')->on('ref_kode_rekening_3');
            $table->foreign('ref_kode_rekening_4')->references('id')->on('ref_kode_rekening_4');
            $table->foreign('ref_kode_rekening_5')->references('id')->on('ref_kode_rekening_5');
            $table->foreign('ref_kode_rekening_6')->references('id')->on('ref_kode_rekening_6');
            $table->foreign('created_by')->references('id')->on('users');
            $table->foreign('updated_by')->references('id')->on('users');
            $table->foreign('deleted_by')->references('id')->on('users');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('data_realisasi_contracts');
    }
};
