<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Models\Ref\Bidang;
use App\Models\Ref\Kegiatan;
use App\Models\Ref\Program;
use App\Models\Ref\SubKegiatan;
use App\Models\Ref\Urusan;

class TestingController extends Controller
{
    function index()
    {
        $datas = [];
        return response()->json([
            'message' => 'success',
            'data' => $datas,
        ]);
    }
}
